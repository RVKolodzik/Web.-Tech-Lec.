A Pen created at CodePen.io. You can find this one at http://codepen.io/inf3cti0n95/pen/QEvzJX.

 Here is an Animated Navigation Menu Concept for Landing Page for My On Going Project.
Animations with GSAP and CSS animations for the SVGs.

All the SVG's are Created by me :) Feel free to Use them in your projects.

Hover Over the Elements for Eye Tracking :)